.. _tutorial-testing:

Bonus: Testing the Application
==============================

Now that you have finished the application and everything works as
expected, it's probably not a bad idea to add automated tests to simplify
modifications in the future.  The application above is used as a basic
example of how to perform unittesting in the :ref:`testing` section of the
documentation.  Go there to see how easy it is to test Flask applications.
