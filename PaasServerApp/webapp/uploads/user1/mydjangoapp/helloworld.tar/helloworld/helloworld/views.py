# -*- coding: utf-8 -*-
from django.http import HttpResponse
from django.template import RequestContext, loader, Context

def index(request):
    t = loader.get_template('index.html')
    c= Context({'foo': 'bar'})
    #return HttpResponse("Hello, world!")
    return HttpResponse(t.render(c))
