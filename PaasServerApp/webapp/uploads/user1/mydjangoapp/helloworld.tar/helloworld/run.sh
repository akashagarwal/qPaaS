#!/bin/sh # default parameters 
: ${APP_USER:=app} 
: ${WEB_CONCURRENCY:=1} 
export WEB_CONCURRENCY if [ "x$(whoami)" != "x$APP_USER" ];then 
# ensure we own our storage 
chown -R "$APP_USER" /static /storage # Call back into ourselves as the app user 
exec sudo -sE -u "$APP_USER" -- "$0" "$@" 
else 
. ./startenv 
case "$1" in 
deploy) shift 1 # consume command from $@ 
./manage.py migrate "$@" 
;; 
serve) 
gunicorn -w "$WEB_CONCURRENCY" -b 0.0.0.0:8000 "${APP}.wsgi:application" ;; 
*) ./manage.py "$@" 
;;
esac fi  
